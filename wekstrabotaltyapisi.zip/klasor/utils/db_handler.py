import sqlite3

def init_db():
    conn = sqlite3.connect('database.db')
    cursor = conn.cursor()
    # Raporlar tablosu
    cursor.execute('''CREATE TABLE IF NOT EXISTS reports 
        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
        reporter_id TEXT, reported_id TEXT, reason TEXT, timestamp DATETIME)''')
    # Yasak/Susturma kayıtları tablosu
    cursor.execute('''CREATE TABLE IF NOT EXISTS logs 
        (id INTEGER PRIMARY KEY AUTOINCREMENT, 
        target_id TEXT, mod_id TEXT, action TEXT, reason TEXT, timestamp DATETIME)''')
    conn.commit()
    conn.close()

def add_report(reporter, reported, reason):
    conn = sqlite3.connect('database.db')
    c = conn.cursor()
    c.execute("INSERT INTO reports (reporter_id, reported_id, reason, timestamp) VALUES (?, ?, ?, datetime('now'))",
              (str(reporter), str(reported), reason))
    conn.commit()
    conn.close()