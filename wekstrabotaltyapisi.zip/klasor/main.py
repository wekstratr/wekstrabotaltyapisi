import discord
from discord.ext import commands
import os
from utils.db_handler import init_db

class MyBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.all()
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        init_db() # Veritabanını başlat
        # Cogs klasöründeki tüm dosyaları yükle
        for filename in os.listdir('./cogs'):
            if filename.endswith('.py'):
                await self.load_extension(f'cogs.{filename[:-3]}')
        await self.tree.sync()

bot = MyBot()
bot.run("TOKEN_BURAYA")