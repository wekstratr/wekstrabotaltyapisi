import discord
from discord.ext import commands

class Filters(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        # Buraya engellemek istediğin kelimeleri ekle
        self.blacklist = ["aq", "oe", "oç" , "amk" ] 

    @commands.Cog.listener()
    async def on_message(self, message):
        if message.author.bot:
            return

        content = message.content.lower()
        if any(word in content for word in self.blacklist):
            try:
                await message.delete()
                await message.channel.send(f"⚠️ {message.author.mention}, bu sunucuda küfürlü içerik yasaktır!", delete_after=3)
            except discord.Forbidden:
                print("Mesajı silme yetkim yok!")

async def setup(bot):
    await bot.add_cog(Filters(bot))