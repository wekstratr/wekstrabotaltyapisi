import discord
from discord import app_commands
from discord.ext import commands
from utils.db_handler import add_report
import sqlite3

class Reporting(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="raporla", description="Bir kullanıcıyı raporlar")
    async def raporla(self, interaction: discord.Interaction, kullanici: discord.Member, neden: str):
        add_report(interaction.user.id, kullanici.id, neden)
        
        embed = discord.Embed(title="Yeni Rapor Kaydedildi", color=discord.Color.red())
        embed.add_field(name="Raporlanan", value=kullanici.mention)
        embed.add_field(name="Sebep", value=neden)
        
        await interaction.response.send_message("Raporunuz başarıyla veritabanına kaydedildi.", ephemeral=True)

    @app_commands.command(name="raporlar", description="Kullanıcı veya Moderatör geçmişine bakar")
    async def raporlar(self, interaction: discord.Interaction, hedef: discord.Member):
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        
        # Kullanıcının raporlandığı kayıtları çek
        c.execute("SELECT reporter_id, reason, timestamp FROM reports WHERE reported_id = ?", (str(hedef.id),))
        results = c.fetchall()
        
        embed = discord.Embed(title=f"Rapor Geçmişi: {hedef.name}", color=discord.Color.blue())
        if not results:
            embed.description = "Bu kullanıcıya ait bir kayıt bulunamadı."
        for row in results:
            embed.add_field(name=f"Tarih: {row[2]}", value=f"Raporlayan: <@{row[0]}>\nNeden: {row[1]}", inline=False)
            
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Reporting(bot))