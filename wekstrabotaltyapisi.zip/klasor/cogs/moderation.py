import discord
from discord import app_commands
from discord.ext import commands
import datetime
import sqlite3

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.invite_link = "https://discord.gg/sunuculinkiniz"

    def log_to_db(self, target_id, mod_id, action, reason):
        conn = sqlite3.connect('database.db')
        c = conn.cursor()
        c.execute("INSERT INTO logs (target_id, mod_id, action, reason, timestamp) VALUES (?, ?, ?, ?, datetime('now'))",
                  (str(target_id), str(mod_id), action, reason))
        conn.commit()
        conn.close()

    @app_commands.command(name="yasakla", description="Kullanıcıyı yasaklar")
    @app_commands.checks.has_permissions(ban_members=True)
    async def yasakla(self, interaction: discord.Interaction, kullanici: discord.Member, nedeni: str):
        await kullanici.ban(reason=nedeni)
        self.log_to_db(kullanici.id, interaction.user.id, "Yasaklama", nedeni)
        
        embed = discord.Embed(title="🔨 Yasaklama Kaydı", color=discord.Color.red())
        embed.description = f"Bu kişi **{nedeni}** nedeniyle **{interaction.user.name}** tarafından yasaklandı."
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="yasakkaldir", description="Yasağı kaldırır ve kullanıcıya DM atar")
    @app_commands.checks.has_permissions(ban_members=True)
    async def yasakkaldir(self, interaction: discord.Interaction, kullanici_id: str, nedeni: str):
        user = await self.bot.fetch_user(kullanici_id)
        await interaction.guild.unban(user, reason=nedeni)
        self.log_to_db(user.id, interaction.user.id, "Yasak Kaldırma", nedeni)

        try:
            embed = discord.Embed(title="Yasağınız Kaldırıldı", color=discord.Color.green())
            embed.description = f"Merhaba {user.name}, **{interaction.guild.name}** sunucusundaki yasağınız **{interaction.user.name}** tarafından **{nedeni}** nedeniyle kaldırılmıştır.\n\n[Buraya tıklayarak tekrar katılabilirsiniz]({self.invite_link})"
            await user.send(embed=embed)
        except:
            pass
        await interaction.response.send_message(f"✅ {user.name} yasağı kaldırıldı.")

    @app_commands.command(name="sustur", description="Kullanıcıyı süreli susturur")
    @app_commands.checks.has_permissions(moderate_members=True)
    async def sustur(self, interaction: discord.Interaction, kullanici: discord.Member, dakika: int, nedeni: str):
        sure = datetime.timedelta(minutes=dakika)
        await kullanici.timeout(sure, reason=nedeni)
        self.log_to_db(kullanici.id, interaction.user.id, "Susturma", nedeni)

        embed = discord.Embed(title="🔇 Susturma Kaydı", color=discord.Color.orange())
        embed.description = f"Bu kullanıcı **{nedeni}** nedeniyle **{dakika} dakika** süreyle **{interaction.user.name}** tarafından susturuldu."
        await interaction.response.send_message(embed=embed)
        
        try:
            await kullanici.send(f"{interaction.guild.name} sunucusunda {dakika} dakika susturuldunuz. Neden: {nedeni}")
        except:
            pass

    @app_commands.command(name="kullanicibilgisi", description="Kullanıcı hakkında bilgi verir")
    async def kullanicibilgisi(self, interaction: discord.Interaction, kullanici: discord.Member):
        embed = discord.Embed(title=f"Kullanıcı Bilgisi: {kullanici.name}", color=discord.Color.blue())
        embed.add_field(name="Giriş Tarihi", value=kullanici.joined_at.strftime("%d/%m/%Y"), inline=True)
        embed.add_field(name="Roller", value=", ".join([role.name for role in kullanici.roles if role.name != "@everyone"]), inline=False)
        embed.set_thumbnail(url=kullanici.avatar.url if kullanici.avatar else None)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Moderation(bot))